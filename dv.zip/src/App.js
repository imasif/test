import "./App.css";
import Home from "./screens/home";

function App() {
  return <Home />;
}

export default App;
