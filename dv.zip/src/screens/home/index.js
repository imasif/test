import "../../App.css";
import Dropdown from "react-dropdown";
import "react-dropdown/style.css";
import { useState } from "react";
import Checkbox from "react-custom-checkbox";
import {
  Accordion,
  AccordionItem,
  AccordionItemHeading,
  AccordionItemButton,
  AccordionItemPanel,
} from "react-accessible-accordion";
import "react-accessible-accordion/dist/fancy-example.css";
import CountDown from "../../components/countdown";

function Home() {
  const [checked, setChecked] = useState(false);

  const handleChange = () => {
    setChecked(!checked);
  };
  const options = [
    {
      value: "en",
      label: (
        <div>
          <img
            src={require("../../assets/en.png")}
            className="languageSelectorImg"
          />
          English
        </div>
      ),
    },
    {
      value: "es",
      label: (
        <div>
          <img
            src={require("../../assets/es.png")}
            className="languageSelectorImg"
          />
          Spanish
        </div>
      ),
    },
  ];
  const defaultOption = options[0];

  const options2 = [
    {
      value: "us",
      label: "United States",
    },
    {
      value: "ca",
      label: "Canada",
    },
  ];

  const options3 = [
    {
      value: "single",
      label: "Single",
    },
    {
      value: "married",
      label: "Married",
    },
  ];

  return (
    <div className="App">
      <header className="App-header">
        <nav>
          <img
            alt="logo"
            src={require("../../assets/logo.png")}
            width={208}
            height={104}
          />

          <div className="nav_right_content">
            <Dropdown
              options={options}
              className="language_selector"
              onChange={() => {}}
              value={defaultOption}
              placeholder="Select an option"
            />
            ;<button>Live chat</button>
          </div>
        </nav>
        <div className="background_gradient">
          <div className="container">
            <div className="inner_area">
              <div className="left_area">
                <div className="left_area_inner">
                  <h1>Win the right to live</h1>
                  <h2>in the USA!</h2>

                  <div className="mid">
                    <div className="mid_inner">
                      <h3>
                        The official deadline is running, so hurry up and{" "}
                        <a href="#">apply here!</a>
                      </h3>

                      <CountDown />
                    </div>

                    <div className="header_bottom_area_left">
                      <h4>
                        <img
                          className="left_icon"
                          src={require("../../assets/icon_people.png")}
                          alt="left icon"
                        />
                        50,000 people and their families will Live, Work and
                        Study in USA.
                      </h4>
                      <h4>
                        <img
                          className="left_icon"
                          src={require("../../assets/icon_medalstar.png")}
                          alt="left icon"
                        />
                        OFFICIAL USA Governmental program.
                      </h4>
                      <h4>
                        <img
                          className="left_icon"
                          src={require("../../assets/icon_walletcheck.png")}
                          alt="left icon"
                        />
                        Your chance to LIVE, WORK & STUDY in USA.
                      </h4>
                      <h4>
                        <img
                          className="left_icon"
                          src={require("../../assets/icon_clock.png")}
                          alt="left icon"
                        />
                        Simple registration within 5 minutes.
                      </h4>
                      <h4>
                        <img
                          className="left_icon"
                          src={require("../../assets/icon_message.png")}
                          alt="left icon"
                        />
                        Personal support in every step.
                      </h4>
                      <h4>
                        <img
                          className="left_icon"
                          src={require("../../assets/icon_lovely.png")}
                          alt="left icon"
                        />
                        Double chance for married people to win the Green Card.
                      </h4>
                    </div>
                  </div>
                </div>
              </div>
              <div className="right_area">
                <form className="green_card_eligibility" action="#">
                  <h4>
                    <div className="icon_arrow">
                      <img
                        src={require("../../assets/icon_arrow_right.png")}
                        alt="green card arrow"
                      />
                    </div>
                    Check now for free
                  </h4>

                  <h1>Green card eligibility</h1>
                  <div className="form_row">
                    <input type="text" placeholder="First Name" />
                    <input type="text" placeholder="Last Name" />
                  </div>
                  <div className="form_row">
                    <input type="text" placeholder="Email Address" />
                    <input type="text" placeholder="Your email again" />
                  </div>
                  <div className="form_row">
                    <Dropdown
                      options={options2}
                      className="form_selector"
                      onChange={() => {}}
                      placeholder="Your country of birth"
                    />
                  </div>
                  <div className="form_row">
                    <Dropdown
                      options={options3}
                      className="form_selector"
                      onChange={() => {}}
                      placeholder="Marital Status"
                    />
                  </div>
                  <div className="form_row">
                    <Checkbox
                      className="agree_checkbox"
                      borderColor="#170A61"
                      labelStyle={{ color: "#01264A" }}
                      icon={
                        <img
                          src={require("../../assets/check.png")}
                          style={{ width: 18 }}
                          alt=""
                        />
                      }
                      style={{ cursor: "pointer", marginRight: 20 }}
                      label="Yes, I finished high school OR I have qualifying training."
                    />
                  </div>
                  <div className="form_row">
                    <button className="continue_button">Continue</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </header>
      <div className="middle_contents">
        <div className="find_right_visa">
          <img
            style={{ marginRight: 20 }}
            src={require("../../assets/icon_document_text.png")}
            width={22}
            height={22}
          />
          Find the right visa for you!
        </div>
        <div className="inner_container">
          <Accordion>
            <AccordionItem>
              <AccordionItemHeading>
                <AccordionItemButton>
                  What harsh truths do you prefer to ignore?
                </AccordionItemButton>
              </AccordionItemHeading>
              <AccordionItemPanel>
                <p>
                  Exercitation in fugiat est ut ad ea cupidatat ut in cupidatat
                  occaecat ut occaecat consequat est minim minim esse tempor
                  laborum consequat esse adipisicing eu reprehenderit enim.
                </p>
              </AccordionItemPanel>
            </AccordionItem>
            <AccordionItem>
              <AccordionItemHeading>
                <AccordionItemButton>
                  Is free will real or just an illusion?
                </AccordionItemButton>
              </AccordionItemHeading>
              <AccordionItemPanel>
                <p>
                  In ad velit in ex nostrud dolore cupidatat consectetur ea in
                  ut nostrud velit in irure cillum tempor laboris sed
                  adipisicing eu esse duis nulla non.
                </p>
              </AccordionItemPanel>
            </AccordionItem>
          </Accordion>
        </div>
      </div>
    </div>
  );
}

export default Home;
